module.exports.config = {
  name: "ريكو-ترحيب",
  eventType: ["log:subscribe"],
  version: "1.0.1",
  credits: "عزيز✦",
  description: "ترحيب بالعضاء الجدد + تأكيد اتصال البوت + قوانين"
};

module.exports.run = async function({ api, event, Users }) {
  const { threadID } = event;

  if (event.logMessageData.addedParticipants.some(i => i.userFbId == api.getCurrentUserID())) {
    api.changeNickname(`『 ${global.config.PREFIX} 』⟩⟩ Rɪᴋᴏ-Bᴏᴛ 🐺`, threadID, api.getCurrentUserID());
    return api.sendMessage(
      `⪼『 ✅ 』⪻\n✧ بـــوت ✦ رِيـــــكو ✦ راهـو متـــصل وخدام ⌬\n⪼ تم التثبيت بنجاح في القروب ✨\n\n⚠️ قَوانِين القُــروب:\n━━━━━━━━━━━━━━\n➤ إحترم الأعضاء كامل\n➤ ممنوع السب والشتم\n➤ أي تجاوز = طــرد تلقائي\n➤ لا تسپام ولا روابط\n➤ تڨدر تسقسي البوت على الأوامر بكتابة "الاوامر"\n━━━━━━━━━━━━━━\n⌬ مطور البوت: 『 عـزيـز ⚡ 』\n⌬ برافو خيـو، القروب نور بيك ✨`,
      threadID
    );
  } else {
    try {
      const { createReadStream, existsSync } = global.nodemodule["fs-extra"];
      const { threadName, participantIDs } = await api.getThreadInfo(threadID);
      const nameArray = [], mentions = [];
      for (const p of event.logMessageData.addedParticipants) {
        nameArray.push(p.fullName);
        mentions.push({ tag: p.fullName, id: p.userFbId });
      }

      const moment = require("moment-timezone");
      const time = moment.tz("Africa/Algiers").format("HH:mm:ss - DD/MM/YYYY");

      const msg = 
`╭━─[ ⚡ 𝑊𝐸𝐿𝐶𝑂𝑀𝐸 ⚡ ]─━╮
✧ الســلام عليكم ${nameArray.join(", ")} ✧
• راهي قروب ✦ رِيــــكو ✦ نورت ✨
• عدد الأعضاء: ${participantIDs.length}
• الوقت: ${time}
╰━─[ ⌬ إحترم القوانين وڨعد معنا ]─━╯`;

      const path = require("path");
      const gifPath = path.join(__dirname, "cache", "joinGif", "1.mp4");

      const formPush = existsSync(gifPath)
        ? { body: msg, attachment: createReadStream(gifPath), mentions }
        : { body: msg, mentions };

      return api.sendMessage(formPush, threadID);
    } catch (e) {
      console.error("خطأ في كود الترحيب:", e);
    }
  }
};