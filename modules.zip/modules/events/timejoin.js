module.exports.config = {
    name: "ريكو-وقت-الخروج",
    eventType: ["log:unsubscribe"],
    version: "1.0.0",
    credits: "Nam | Mod by عزيز⚡",
    description: "❌ حذف أوتوماتيكي للوقت تاع دخول العضو كي يخرج"
};

const fs = require("fs");
const path = __dirname + "/../commands/cache/timeJoin.json";

module.exports.run = async function ({ event }) {
    const { threadID, logMessageData } = event;
    const userLeft = logMessageData.leftParticipantFbId;

    try {
        const rawData = fs.readFileSync(path);
        let timeJoinData = JSON.parse(rawData);

        if (timeJoinData.hasOwnProperty(userLeft + threadID)) {
            delete timeJoinData[userLeft + threadID];
            fs.writeFileSync(path, JSON.stringify(timeJoinData, null, 2));
            console.log(`✅ تم حذف وقت دخول العضو ID: ${userLeft} من القروب ${threadID}`);
        } else {
            console.log(`ℹ️ لا يوجد وقت مسجل للعضو ID: ${userLeft} فالقروب ${threadID}`);
        }
    } catch (err) {
        console.error("❌ خطأ أثناء محاولة حذف وقت دخول العضو:", err);
    }
};