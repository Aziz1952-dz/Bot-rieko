module.exports.config = {
    name: "حارس-القروب",
    eventType: ["log:thread-admins"],
    version: "1.0.0",
    credits: "⫷ 𓆩عـزيـز𓆪 ⚡️",
    description: "⫷✦ يمنع تغييرات الأدمن في القروب ✦⫸"
};

module.exports.run = async function ({ event, api, Threads, Users }) {
    const { logMessageType, logMessageData, senderID } = event;
    let data = (await Threads.getData(event.threadID)).data;
    if (data.guard !== true) return;

    switch (logMessageType) {
        case "log:thread-admins": {
            // حالة إضافة أدمن
            if (logMessageData.ADMIN_EVENT == "add_admin") {
                if (event.author == api.getCurrentUserID() || logMessageData.TARGET_ID == api.getCurrentUserID()) return;

                api.changeAdminStatus(event.threadID, event.author, false);
                api.changeAdminStatus(event.threadID, logMessageData.TARGET_ID, false, (err) => {
                    if (err) return api.sendMessage("⚠️ ههه ماقدرتش نمنع التغيير!", event.threadID, event.messageID);
                    return api.sendMessage(
`⛔️ [حِمايـة القُروب مـفعّلة] ⛔️
❌ محاولة غير مصرح بها لإضافة أدمن
تم رفض الطلب واسترجاع الوضع!`,
                        event.threadID, event.messageID
                    );
                });
            }

            // حالة نزع أدمن
            else if (logMessageData.ADMIN_EVENT == "remove_admin") {
                if (event.author == api.getCurrentUserID() || logMessageData.TARGET_ID == api.getCurrentUserID()) return;

                api.changeAdminStatus(event.threadID, event.author, false);
                api.changeAdminStatus(event.threadID, logMessageData.TARGET_ID, true, (err) => {
                    if (err) return api.sendMessage("⚠️ ههه ماقدرتش نرجع الأدمن!", event.threadID, event.messageID);
                    return api.sendMessage(
`⛔️ [وضع الحماية مـفعل] ⛔️
❌ محاولة نزع أدمن بدون صلاحية
رجعتلو المنصب وتم طرد المتسبب!`,
                        event.threadID, event.messageID
                    );
                });
            }
        }
    }
}