module.exports.config = {
  name: "ريكو-لوق",
  eventType: ["log:unsubscribe", "log:subscribe", "log:thread-name"],
  version: "1.0.0",
  credits: "Mirai Team | Mod by عزيز⚡",
  description: "⫷⫸ إشعار تلقائي بالتغييرات داخل القروبات ⫷⫸",
  envConfig: {
    enable: true
  }
};

module.exports.run = async function ({ api, event, Users, Threads }) {
  const logger = require("../../utils/log");
  if (!global.configModule[this.config.name].enable) return;

  const botID = api.getCurrentUserID();
  const allThreadID = global.data.allThreadID;

  for (const singleThread of allThreadID) {
    const thread = global.data.threadData.get(singleThread) || {};
    if (thread["log"] === false) return;
  }

  const moment = require("moment-timezone");
  const time = moment.tz("Africa/Algiers").format("DD/MM/YYYY || HH:mm:ss");

  let threadInfo = await api.getThreadInfo(event.threadID);
  const nameThread = threadInfo.threadName || "✘ إسـم موحود ✘";
  const nameUser = global.data.userName.get(event.author) || await Users.getNameUser(event.author);

  let task = "";
  let formReport = `
⫷⫸ 『 إشعـــــار بوت ريكــــو ✦ 』 ⫷⫸

『 ⚔️ 』 إســــم القــــروب: ${nameThread}
『 🆔 』 آيــــدي القــــروب: ${event.threadID}
『 🔮 』 نــــوع الحــــدث: {task}
『 🧠 』 إســــم المســــتخدم: ${nameUser}
『 🪪 』 آيــــدي المســــتخدم: ${event.author}
『 ⏱️ 』 الوقــــت: ${time}
━━━━━━━━━━━━━━━`;

  switch (event.logMessageType) {
    case "log:thread-name": {
      const newName = event.logMessageData.name || "✘ إسـم موحود ✘";
      await Threads.setData(event.threadID, { name: newName });
      task = `قام بتغيير إسـم القروب إلى ✦ 『 ${newName} 』`;
      break;
    }

    case "log:subscribe": {
      if (event.logMessageData.addedParticipants.some(i => i.userFbId == botID)) {
        task = "تم إضافــة بوت 『 ريكـــو ⚡ 』للقــروب ✦ شكرا على الثقة";
      }
      break;
    }

    case "log:unsubscribe": {
      if (event.logMessageData.leftParticipantFbId == botID) {
        if (event.senderID == botID) return;

        const data = (await Threads.getData(event.threadID)).data || {};
        data.banned = true;
        const reason = "بوت ريكو تـم طردو ⚠️ - علامة حمراء على القروب";
        data.reason = reason;
        data.dateAdded = time;

        await Threads.setData(event.threadID, { data });
        global.data.threadBanned.set(event.threadID, {
          reason: data.reason,
          dateAdded: data.dateAdded
        });

        task = "❌ راني تـم طـردي من القروب ✘\n❗سجّلت القروب في القائمة السوداء ⚠️";
      }
      break;
    }
  }

  if (!task.length) return;

  formReport = formReport.replace("{task}", task);

  return api.sendMessage(formReport, global.config.ADMINBOT[0], (err) => {
    if (err) return logger(formReport, "Logging Event");
  });
};