module.exports.config = {
  name: "تفاعل",
  eventType: ["message"],
  version: "1.0",
  credits: "ChatGPT DZ",
  description: "يتفاعل مع الكلمات بريأكشون"
};

module.exports.run = async function({ api, event }) {
  const { body, threadID, messageID } = event;
  if (!body) return;

  const text = body.toLowerCase();

  // كلمات و الريأكشون المناسب ليها
  const reactions = {
    "سلام": "❤",
    "زبي": "😆",
    "زعفان": "😡",
    "بكيت": "😢",
    "ريكو": "🤖"
  };

  for (let keyword in reactions) {
    if (text.includes(keyword)) {
      return api.setMessageReaction(reactions[keyword], messageID, threadID, () => {}, true);
    }
  }
};