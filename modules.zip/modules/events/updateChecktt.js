module.exports.config = {
    name: "ريكو-تحديث-التفاعل",
    eventType: ["log:unsubscribe"],
    version: "1.0.0",
    credits: "D-Jukie | Mod by عزيز⚡",
    description: "📤 حذف تفاعل العضو من القروب كي يخرج"
};

module.exports.run = async ({ event, api, Threads }) => { 
    if (event.logMessageData.leftParticipantFbId == api.getCurrentUserID()) return;

    const fs = require("fs");
    const path = require("path");

    const checkttFolder = path.join(__dirname, "../commands/tuongtac/checktt");
    const filePath = path.join(checkttFolder, `${event.threadID}.json`);

    try {
        if (!fs.existsSync(filePath)) return console.log("❌ ملف التفاعل مش موجود");

        let data = JSON.parse(fs.readFileSync(filePath));

        const leftID = event.logMessageData.leftParticipantFbId;
        const index_week = data.week.findIndex(e => e.id == leftID);
        const index_day = data.day.findIndex(e => e.id == leftID);
        const index_total = data.total.findIndex(e => e.id == leftID);

        if (index_week !== -1) data.week.splice(index_week, 1);
        if (index_day !== -1) data.day.splice(index_day, 1);
        if (index_total !== -1) data.total.splice(index_total, 1);

        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
        console.log(`✅ تم حذف تفاعل العضو ID: ${leftID} من القروب ${event.threadID}`);
    } catch (err) {
        console.error("❌ خطأ أثناء حذف التفاعل:", err);
    }
};