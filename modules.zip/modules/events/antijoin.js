module.exports.config = {
	name: "طرد-المنضمين",
	eventType: ["log:subscribe"],
	version: "1.0.3",
	credits: "⫷ 𓆩عـزيـز𓆪 ⚡️",
	description: "⫷✦ يمنع دخول أي عضو للقروب تلقائياً ✦⫸"
};

module.exports.run = async function({ api, event, Users }) {
  const { threadID } = event;
  const memJoin = event.logMessageData.addedParticipants.map(info => info.userFbId);

  for (let idUser of memJoin) {
    const { readFileSync } = global.nodemodule["fs-extra"];
    const { resolve } = global.nodemodule["path"];
    const path = resolve(__dirname, '../commands', 'cache', 'antijoin.json');
    const { antijoin } = require(path);
    const dataJson = JSON.parse(readFileSync(path, "utf-8"));

    if (antijoin.hasOwnProperty(threadID) && antijoin[threadID] === true) {
      try {
        setTimeout(async () => {
          await api.removeUserFromGroup(idUser, threadID);
          return api.sendMessage(
            `⛔️⫷ واحد دخل وتم طردو تلقائياً!
⫸ الأنتيجوين مفعل فهاذ القروب ✅`,
            threadID
          );
        }, 1000);
      } catch (e) {
        return api.sendMessage(
          `⚠️⫷ فشل فـ طرد العضو، ممكن راهو أدمن ولا خطأ!`,
          threadID
        );
      }
    }
  }
};