module.exports.config = {
    name: "رجّع-ليخرج",
    eventType: ["log:unsubscribe"],
    version: "1.0.0",
    credits: "⫷ 𓆩عـزيـز𓆪 ⚡️",
    description: "⫷✦ يرجّع أي عضو خرج من القروب ✦⫸"
};

module.exports.run = async({ event, api, Threads, Users }) => {
    let data = (await Threads.getData(event.threadID)).data || {};

    // إذا ماكانش مفعّل "antiout" فالقروب، نحبس
    if (!data.antiout) return;

    // إذا اللي خرج هو البوت، منحبش يرجّع روحو
    if (event.logMessageData.leftParticipantFbId == api.getCurrentUserID()) return;

    // نجيبو اسم الشخص لي خرج
    const name = global.data.userName.get(event.logMessageData.leftParticipantFbId) || await Users.getNameUser(event.logMessageData.leftParticipantFbId);

    // نشوف واش خرج بروحو ولا طردوه
    const type = (event.author == event.logMessageData.leftParticipantFbId) ? "خرج بروحو" : "طردوه";

    // إذا خرج بروحو، نحاولو نرجّعوه
    if (type === "خرج بروحو") {
        api.addUserToGroup(event.logMessageData.leftParticipantFbId, event.threadID, (error, info) => {
            if (error) {
                api.sendMessage(
`⛔️⫷ مانقدرش نرجّع ${name} للقروب ❌
⚠️ ممكن راهو حظر البوت أو الإضافة معطّلة!`,
                event.threadID);
            } else {
                api.sendMessage(
`✅⫷ رجّعنا ${name} للقروب من جديد!
✦ ما تروحش بعيد خويا، القعدة مازالت دايرة.`,
                event.threadID);
            }
        });
    }
}