module.exports.config = {
  name: "ريكو-مغادرة",
  eventType: ["log:unsubscribe"],
  version: "1.0.0",
  credits: "عزيز✦",
  description: "إشعار عند مغادرة شخص مع صورة أو فيديو عشوائي",
  dependencies: {
    "fs-extra": "",
    "path": ""
  }
};

const checkttPath = __dirname + '/../commands/tuongtac/checktt/'

module.exports.onLoad = function () {
  const { existsSync, mkdirSync } = global.nodemodule["fs-extra"];
  const { join } = global.nodemodule["path"];

  const path = join(__dirname, "cache", "leaveGif", "randomgif");
  if (!existsSync(path)) mkdirSync(path, { recursive: true });
};

module.exports.run = async function ({ api, event, Users, Threads }) {
  if (event.logMessageData.leftParticipantFbId == api.getCurrentUserID()) return;

  const { createReadStream, existsSync, readdirSync, readFileSync, writeFileSync } = global.nodemodule["fs-extra"];
  const { join } = global.nodemodule["path"];
  const { threadID } = event;
  const moment = require("moment-timezone");
  const time = moment.tz("Africa/Algiers").format("DD/MM/YYYY || HH:mm:ss");
  const hours = parseInt(moment.tz("Africa/Algiers").format("HH"));

  const data = global.data.threadData.get(parseInt(threadID)) || (await Threads.getData(threadID)).data;
  const iduser = event.logMessageData.leftParticipantFbId;
  const name = global.data.userName.get(iduser) || await Users.getNameUser(iduser);
  const type = (event.author == iduser) ? "خـرج بـراحتو" : "تـم طردو من طرف الأدمن";

  const session = hours < 12 ? "الصـباح" : hours < 18 ? "العشيـة" : "اللّيل";

  // حذفو من التفاعل
  if (existsSync(checkttPath + threadID + '.json')) {
    const threadData = JSON.parse(readFileSync(checkttPath + threadID + '.json'));
    threadData.total = threadData.total.filter(e => e.id !== iduser);
    threadData.week = threadData.week.filter(e => e.id !== iduser);
    threadData.day = threadData.day.filter(e => e.id !== iduser);
    writeFileSync(checkttPath + threadID + '.json', JSON.stringify(threadData, null, 4));
  }

  let msg = data.customLeave || `⫷⫸ شوف شوف ⫷⫸\n『 {name} 』 راهو {type} ✌🏻\n⏱: {time}\n✦ الوقت الحالي: {session}\n➥ كي تـولي ڨولنا، وراك رايح؟`;

  msg = msg
    .replace(/\{name}/g, name)
    .replace(/\{iduser}/g, iduser)
    .replace(/\{type}/g, type)
    .replace(/\{session}/g, session)
    .replace(/\{time}/g, time);

  const randomPath = readdirSync(join(__dirname, "cache", "leaveGif", "randomgif"));
  const pathGif = join(__dirname, "cache", "leaveGif", "randomgif", `${threadID}`);
  let formPush = {};

  if (existsSync(pathGif)) {
    formPush = { body: msg, attachment: createReadStream(pathGif) };
  } else if (randomPath.length !== 0) {
    const pathRandom = join(__dirname, "cache", "leaveGif", "randomgif", `${randomPath[Math.floor(Math.random() * randomPath.length)]}`);
    formPush = { body: msg, attachment: createReadStream(pathRandom) };
  } else {
    formPush = { body: msg };
  }

  return api.sendMessage(formPush, threadID);
};