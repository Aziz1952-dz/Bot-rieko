module.exports.config = {
  name: "لقب-البوت",
  eventType: ["log:user-nickname"],
  version: "1.0.0",
  credits: "⫷ 𓆩عـزيـز𓆪 ⚡️",
  description: "⫷✦ منع أي واحد يبدّل لقب البوت بلا صلاحيات ✦⫸"
};

module.exports.run = async function({ api, event, Users, Threads }) {
  var { logMessageData, threadID, author } = event;
  var botID = api.getCurrentUserID();
  var { BOTNAME, ADMINBOT } = global.config;
  var { nickname } = await Threads.getData(threadID, botID);

  var nickname = nickname ? nickname : `『 ${global.config.PREFIX} 』⪼ ${BOTNAME}`;

  if (logMessageData.participant_id == botID && author != botID && !ADMINBOT.includes(author) && logMessageData.nickname != nickname) {
    api.changeNickname(nickname, threadID, botID);

    var info = await Users.getData(author);

    return api.sendMessage({
      body:
`⫷⛔️⫸ ⤷  ✦  ${info.name} ✦
❖ مـاتبدّليش لقب البوت يا نينجا!
❖ راني رجّعتو كيما كان، بصح نزيد نقولّك:
❖ عندك ماشي صلاحيات باش تبدّل لقب ✘

⫷ توقيع ⫸
『 ⱯⱫłⱫ - 𓆩 ᴀʟɢᴇʀɪᴀɴ ᴘʀᴏɢʀᴀᴍᴍᴇʀ 𓆪 』`
    }, threadID);
  }  
}