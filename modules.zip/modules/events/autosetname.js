module.exports.config = {
	name: "تعيين-اللقب",
	eventType: ["log:subscribe"],
	version: "1.0.3",
	credits: "⫷ 𓆩عـزيـز𓆪 ⚡️",
	description: "⫷✦ يبدل لقب أي عضو جديد تلقائياً ✦⫸"
};

module.exports.run = async function({ Threads, api, event, Users }) {
  const { createReadStream, existsSync, mkdirSync, readdirSync, readFileSync } = global.nodemodule["fs-extra"];
  const { join } = global.nodemodule["path"];
  const moment = require("moment-timezone");

  const { threadID } = event;
  let memJoin = event.logMessageData.addedParticipants.map(info => info.userFbId);

  // توقيت جزائري مزخرف
  let heure = moment.tz("Africa/Algiers").format("HH:mm:ss || DD/MM/YYYY");
  let jour = moment.tz('Africa/Algiers').format('dddd');
  const joursTrad = {
    Sunday: "الأحد", Monday: "الإثنين", Tuesday: "الثلاثاء",
    Wednesday: "الأربعاء", Thursday: "الخميس", Friday: "الجمعة", Saturday: "السبت"
  };
  jour = joursTrad[jour] || jour;

  for (let idUser of memJoin) {
    const pathData = join(__dirname, "../commands", "cache", "data", "autosetname.json");
    var dataJson = JSON.parse(readFileSync(pathData, "utf-8"));
    var thisThread = dataJson.find(item => item.threadID == threadID) || { threadID, nameUser: [] };

    if (thisThread.nameUser.length == 0) return;

    // تعيين اللقب
    let prefixName = thisThread.nameUser[0];
    await new Promise(resolve => setTimeout(resolve, 1000));
    let userInfo = await api.getUserInfo(idUser);
    let fullName = userInfo[idUser].name;

    await api.changeNickname(`${prefixName} ${fullName}`, threadID, idUser);
  }

  // إرسال رسالة مع ملف صوتي
  const gifPath = join(__dirname, "cache", "autosetname", "autosetname.mp3");
  const randomFiles = readdirSync(join(__dirname, "cache", "autosetname", "randomgif"));

  return api.sendMessage({
    body:
`⫷✦『 عملية التعيين تمت بنجاح 』✦⫸
━━━━━━━━━━━━━━
⫸ راه تبدل لقب العضو الجديد تلقائياً.
⫸ خليك محترف، واللقب زاد جمال القروب!
━━━━━━━━━━━━━━
⫷ ${jour} ⧸ ${heure} ⫸`,
    attachment: createReadStream(gifPath)
  }, threadID, event.messageID);
};