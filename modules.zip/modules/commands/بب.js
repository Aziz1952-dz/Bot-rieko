const axios = require("axios");

module.exports.config = {
  name: "ريكو",
  version: "1.0.0",
  credits: "Aziz",
  description: "ذكاء إصطناعي يجاوب بلا بريفيكس",
  usages: "[سؤال]",
  hasPrefix: false,
  cooldowns: 2,
};

module.exports.run = async function({ api, event, args }) {
  const question = args.join(" ");
  if (!question) return api.sendMessage("⛔ | قولّي وش تحب نسقسي عليه يا خو!", event.threadID, event.messageID);

  try {
    const res = await axios.get(`https://aziz-reeko-api.onrender.com/reeko?ask=${encodeURIComponent(question)}`);
    const answer = res.data.answer;
    return api.sendMessage(`🤖 | ريكو جاوبك:\n\n${answer}`, event.threadID, event.messageID);
  } catch (err) {
    return api.sendMessage("❌ | صرات غلطة وأنا نحاول نصلحها، جرب عاود بعد شوية!", event.threadID, event.messageID);
  }
};