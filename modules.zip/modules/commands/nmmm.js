const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');

module.exports.config = {
    name: "تخيل",
    version: "1.0",
    hasPermission: 0,
    credits: "عزيز بالزخرفة",
    description: "يرسم صور من نص معين بلا بريفيكس",
    commandCategory: "ذكاء صناعي",
    usages: "[نص] [رقم ستايل] [حجم (rto)]",
    cooldowns: 5
};

module.exports.handleEvent = async function ({ api, event }) {
    const content = event.body.toLowerCase();
    const match = content.match(/(?:يا)?تخيل(?:لي)? (.+)/i);
    if (!match) return;

    const fullArgs = match[1].trim().split(" ");
    if (fullArgs.length < 2) {
        return api.sendMessage("💡 قوللي: تخيل [النص] [ستايل] [الحجم (rto)]", event.threadID, event.messageID);
    }

    try {
        const ayoub = fullArgs.slice(0, -2).join(" ");
        const style = fullArgs[fullArgs.length - 2];
        let rto = fullArgs[fullArgs.length - 1];

        if (!rto || isNaN(rto)) rto = 1;
        else rto = parseInt(rto);

        const translateURL = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(ayoub)}`;
        const translationResponse = await axios.get(translateURL);
        const promptEn = translationResponse.data[0][0][0];

        const bodyData = {
            prompt: promptEn,
            sty: style,
            rto: rto
        };

        api.sendMessage("⏳ راهي تتخيل الصورة... صبر شوية", event.threadID, event.messageID);

        const res = await axios.post("https://app-dodogen-835c6bdca048.herokuapp.com/gen", bodyData);
        const images = res.data.url;

        const attachments = [];

        for (let i = 0; i < images.length; i++) {
            const imgURL = images[i];
            const imgRes = await axios.get(imgURL, { responseType: 'arraybuffer' });
            const imgPath = path.join(__dirname, 'cache', `imag${i + 1}.jpg`);
            await fs.outputFile(imgPath, imgRes.data);
            attachments.push(fs.createReadStream(imgPath));
        }

        await api.sendMessage({
            body: `✨ هاني رسمتلك: "${ayoub}"\n🎨 ستايل رقم: ${style} | حجم: ${rto}`,
            attachment: attachments
        }, event.threadID, event.messageID);

    } catch (err) {
        console.error(err);
        api.sendMessage("⚠️ صرات غلطة في توليد الصورة !\nجرب حاجة أسهل ولا عاود المحاولة.", event.threadID, event.messageID);
    }
};

module.exports.run = async () => {};