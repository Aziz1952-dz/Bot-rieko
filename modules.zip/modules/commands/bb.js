const axios = require('axios');

module.exports.config = {
    name: "ريكو",
    version: "2.3.4",
    hasPermission: 0,
    credits: "AZIZ",
    description: "إجابة على الأسئلة باستخدام GPT API",
    commandCategory: "ذكاء اصطناعي",
    usages: "ريكو [سؤالك]",
    cooldowns: 1,
    usePrefix: false // باش يولي يخدم بلا بريفيكس
};

module.exports.handleEvent = async function ({ api, event }) {
    const { body, threadID, senderID } = event;

    // نتأكد أنو الرسالة تبدا بكلمة "ريكو"
    if (!body || !body.toLowerCase().startsWith("ريكو")) return;

    const userQuery = body.slice(4).trim(); // ننزع كلمة "ريكو"

    if (!userQuery) {
        return api.sendMessage("أكتب سؤوال لي تحب نجاوب عليك !🙂 .", threadID);
    }

    const apiURL = `https://gpt-3-nf8n.onrender.com/chat?text=${encodeURIComponent(userQuery)}`;

    try {
        const response = await axios.get(apiURL);
        const reply = response.data.reply || response.data;

        const formattedReply = `
┌───────────┐
│ 🤖  𝐫𝐢𝐤𝐨 𝐀𝐥 │
└───────────┘

📌 | (•̀ᴗ•́)و:
「 ${userQuery} 」

💡 | 𝐫𝐞𝐛𝐥𝐲:
「 ${reply} 」

┌───────────┐
│ ✅ 𝐨𝐤 😍  │
└───────────┘
`;

        return api.sendMessage(formattedReply, threadID);
    } catch (error) {
        console.error("Error fetching data from API:", error);
        return api.sendMessage("❌ حدث خطأ أثناء جلب الرد. حاول مرة أخرى لاحقًا.", threadID);
    }
};

// ضروري تبقى فارغة باش ما تخلطش مع أمر البريفيكس
module.exports.run = () => {};