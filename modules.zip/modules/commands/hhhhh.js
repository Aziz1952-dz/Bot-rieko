module.exports.config = {
  name: "طقس",
  version: "1.0.0",
  credits: "ريكو",
  description: "يجيب حالة الطقس"
};

module.exports.run = async ({ api, event, args }) => {
  const axios = require("axios");
  const city = args.join(" ") || "Algiers";
  const res = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=3`);
  api.sendMessage(res.data, event.threadID);
};