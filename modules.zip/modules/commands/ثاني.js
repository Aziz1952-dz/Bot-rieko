const axios = require("axios");
const Scraper = require('mal-scraper');
const request = require('request');
const fs = require("fs");

module.exports.config = {
  name: "تقرير",
  version: "1.0.1",
  hasPermssion: 0,
  credits: "عزيز بالزخرفة",
  description: "يعطيك تقرير على أي أنمي بلا بريفيكس",
  commandCategory: "خدمات",
  usages: "تقرير [اسم الأنمي]",
  cooldowns: 5
};

module.exports.handleEvent = async function({ api, event }) {
  const content = event.body.toLowerCase();
  const match = content.match(/(?:^| )(?:يا)?تقرير(?: عن)? (.+)/i);

  if (!match) return;

  const animeName = match[1].trim();
  if (!animeName) return api.sendMessage("⛔ عطيني اسم الأنمي بعد كلمة تقرير يا خو!", event.threadID, event.messageID);

  api.sendMessage(`🔍 راهي نخدم نجيبلك تقرير على "${animeName}"... صبر شوي`, event.threadID, event.messageID);

  try {
    const Anime = await Scraper.getInfoFromName(animeName);
    if (!Anime) return api.sendMessage("❌ ما لقيتش الأنمي هذا !", event.threadID, event.messageID);

    let imageURL = Anime.picture;
    let ext = imageURL.substring(imageURL.lastIndexOf(".") + 1);
    if (!Anime.genres[0]) Anime.genres[0] = "ماكاش";

    const animeInfo = 
`📺 الإسم: ${Anime.title}
🎌 الإسم بالياباني: ${Anime.japaneseTitle}
📖 النوع: ${Anime.type}
⏱️ الحالة: ${Anime.status}
📆 بدأ العرض: ${Anime.premiered}
🕰️ وقت العرض: ${Anime.broadcast}
📅 تواريخ البث: ${Anime.aired}
🏢 المنتجين: ${Anime.producers}
🏭 الستوديو: ${Anime.studios}
🧾 المصدر: ${Anime.source}
#️⃣ عدد الحلقات: ${Anime.episodes}
⌛ المدة: ${Anime.duration}
🎭 التصنيفات: ${Anime.genres.join(", ")}
🔥 الشعبية: ${Anime.popularity}
🥇 الترتيب: ${Anime.ranked}
⭐ التقييم: ${Anime.score}
⚠️ العمر الموصى به: ${Anime.rating}

📝 القصة:
${Anime.synopsis}

🔗 رابط MAL: ${Anime.url}`;

    const imgPath = __dirname + `/cache/mal.${ext}`;
    const callback = () => {
      api.sendMessage({
        body: animeInfo,
        attachment: fs.createReadStream(imgPath)
      }, event.threadID, () => fs.unlinkSync(imgPath), event.messageID);
    };

    request(imageURL).pipe(fs.createWriteStream(imgPath)).on("close", callback);

  } catch (err) {
    console.error(err);
    api.sendMessage("⚠️ صرات غلطة في جلب التقرير !\nجرب أنمي آخر ولا عاود بعد شوية.", event.threadID, event.messageID);
  }
};

module.exports.run = async () => {}; // نخليها فاضية بصح لازم تكون