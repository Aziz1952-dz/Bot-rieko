module.exports.config = {
  name: "سارق",
  version: "1.0.0",
  credits: "ريكو",
  description: "يختار شخص عشوائي"
};

module.exports.run = async ({ api, event }) => {
  const info = await api.getThreadInfo(event.threadID);
  const id = info.participantIDs[Math.floor(Math.random() * info.participantIDs.length)];
  api.sendMessage({ body: "الحرامي هو:", mentions: [{ tag: "سارق", id }] }, event.threadID);
};