module.exports.config = {
  name: "مساعدة",
  version: "1.0.0", 
  hasPermssion: 0,
  credits: "عزيز",
  description: "قائمة الأوامر المتاحة",
  commandCategory: "النظام",
  usages: "[اسم الأمر]",
  cooldowns: 5
};

module.exports.run = async ({ api, event, args }) => {
  const { commands } = global.client;
  const { threadID, messageID } = event;
  const threadSetting = global.data.threadData.get(parseInt(threadID)) || {};
  const prefix = threadSetting.PREFIX || global.config.PREFIX;

  if (!args[0]) {
    const commandList = Array.from(commands.values());
    const categories = {};
    
    for (const cmd of commandList) {
      const category = cmd.config.commandCategory || "أخرى";
      if (!categories[category]) {
        categories[category] = [];
      }
      categories[category].push(cmd.config.name);
    }

    let msg = "⚡️ قائمة الأوامر المتاحة ⚡️\n\n";
    for (const [category, cmds] of Object.entries(categories)) {
      msg += `「 ${category} 」\n`;
      msg += cmds.join(", ") + "\n\n";
    }
    msg += `\n🔰 استخدم ${prefix}مساعدة + اسم الأمر للحصول على معلومات مفصلة\n`;
    
    return api.sendMessage(msg, threadID, messageID);
  } else {
    const command = commands.get(args[0].toLowerCase());
    if (!command) {
      return api.sendMessage("⚠️ لم يتم العثور على الأمر", threadID, messageID);
    }

    const { name, description, usages, cooldowns, hasPermssion } = command.config;

    const msg = `
🔰 اسم الأمر: ${name}
📝 الوصف: ${description}
🐧 الاستخدام: ${usages}
⏱ وقت الانتظار: ${cooldowns} ثواني
🔰 الصلاحية: ${hasPermssion}
    `.trim();

    return api.sendMessage(msg, threadID, messageID);
  }
};
